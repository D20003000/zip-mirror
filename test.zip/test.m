% 定义目标URL ,matlab2023
targetUrl = 'http://127.0.0.1:8010/refresh';

% 定义循环控制参数
loopInterval = 1; % 循环间隔（秒），每秒请求一次
targetCHX = "1"; % 目标条件：CHX=="1"
isFound = false; % 标记是否找到符合条件的数据
maxLoopTimes = inf; % 最大循环次数（inf为无限循环，可改为具体数值防止死循环）
currentLoop = 0; % 当前循环计数

disp(['开始轮询接口，等待CHX=="', targetCHX, '"，每秒请求一次...']);
disp('===========================================');

% 核心：无限循环（带条件退出+间隔控制）
while(true)
    % 累加循环计数，可选：限制最大循环次数防止死循环
    currentLoop = currentLoop + 1;
    if currentLoop > maxLoopTimes
        disp(['达到最大循环次数（', num2str(maxLoopTimes), '），终止轮询']);
        break;
    end
    
    try
        % 1. 发起HTTP GET请求，获取JSON响应数据
        jsonResponse = webread(targetUrl);
        
        % 2. 兼容原始字符数组和已自动解析的结构体，统一解析为MATLAB结构体
        if ischar(jsonResponse)
            resultStruct = jsondecode(jsonResponse);
        else
            resultStruct = jsonResponse;
        end
        
        % 3. 提取CHX字段，判断是否符合条件
        currentCHX = "";
        if isfield(resultStruct, 'CHX')
            currentCHX = resultStruct.CHX;
        end
        
        disp(['第', num2str(currentLoop), '次轮询 - 当前CHX："', currentCHX, '"']);
        
        % 4. 条件判断：只有CHX=="1"时，才执行后续数据处理和绘图
        if strcmp(currentCHX, targetCHX)
            disp('===========================================');
            disp('找到符合条件的CHX=="1"，开始处理数据并绘图...');
            
            % 5. 提取核心绘图数据（带字段存在性判断，统一转为行数组）
            dataX1 = [];
            dataY1 = [];
            dataY2 = [];
            
            % 提取X轴数据：datax1
            if isfield(resultStruct, 'datax1')
                dataX1 = resultStruct.datax1;
                dataX1 = dataX1(:)'; % 统一为行数组，避免维度问题
                disp(['成功提取DataX1（datax1），原始数据长度：', num2str(length(dataX1))]);
            else
                disp('警告：未找到datax1字段，无法获取X轴数据');
            end
            
            % 提取Y轴数据1：datay1
            if isfield(resultStruct, 'datay1')
                dataY1 = resultStruct.datay1;
                dataY1 = dataY1(:)'; % 统一为行数组
                disp(['成功提取DataY1（datay1），原始数据长度：', num2str(length(dataY1))]);
            else
                disp('警告：未找到datay1字段，无法获取第一组Y轴数据');
            end
            
            % 提取Y轴数据2：datay2
            if isfield(resultStruct, 'datay2')
                dataY2 = resultStruct.datay2;
                dataY2 = dataY2(:)'; % 统一为行数组
                disp(['成功提取DataY2（datay2），原始数据长度：', num2str(length(dataY2))]);
            else
                disp('警告：未找到datay2字段，无法获取第二组Y轴数据');
            end
            
            % 6. 前置处理：三组数据长度对齐
            validLen = min([length(dataX1), length(dataY1), length(dataY2)]);
            if validLen > 0
                dataX1 = dataX1(1:validLen);
                if ~isempty(dataY1)
                    dataY1 = dataY1(1:validLen);
                end
                if ~isempty(dataY2)
                    dataY2 = dataY2(1:validLen);
                end
                disp(['数据长度对齐完成，统一为：', num2str(validLen)]);
            end
            
            % 7. 数据预处理：清洗无效全0序列
            zeroThreshold = 7; % 连续7个0判定为无效数据
            if ~isempty(dataX1)
                dataLen = length(dataX1);
                removeIndices = [];
                
                % 检查前32个数据
                frontRange = 1:min(32, dataLen);
                if ~isempty(frontRange)
                    frontZeroIndices = findContinuousZeroIndices(dataX1(frontRange), zeroThreshold);
                    frontZeroIndices = (frontZeroIndices + frontRange(1) - 1)';
                    removeIndices = [removeIndices, frontZeroIndices];
                end
                
                % 检查后64个数据
                backStart = max(1, dataLen - 63);
                backRange = backStart:dataLen;
                if ~isempty(backRange)
                    backZeroIndices = findContinuousZeroIndices(dataX1(backRange), zeroThreshold);
                    backZeroIndices = (backZeroIndices + backRange(1) - 1)';
                    removeIndices = [removeIndices, backZeroIndices];
                end
                
                % 执行清洗
                removeIndices = unique(sort(removeIndices));
                if ~isempty(removeIndices)
                    dataX1(removeIndices) = [];
                    if ~isempty(dataY1)
                        dataY1(removeIndices) = [];
                    end
                    if ~isempty(dataY2)
                        dataY2(removeIndices) = [];
                    end
                    disp(['成功清洗无效全0数据，移除 ', num2str(length(removeIndices)), ' 个数据点']);
                    disp(['清洗后DataX1长度：', num2str(length(dataX1))]);
                else
                    disp('未检测到需要清洗的连续全0数据，保持原始数据不变');
                end
            end
            
            % 8. 数据合法性校验与绘图
            if isempty(dataX1)
                error('X轴数据为空，无法进行绘图');
            end
            if isempty(dataY1) && isempty(dataY2)
                error('两组Y轴数据均为空，无法进行绘图');
            end
            
            % 绘制二维图
            figure('Name', 'CHX=1 数据趋势图（已清洗）', 'Position', [100, 100, 800, 500]);
            hold on; grid on; box on;
            if ~isempty(dataY1)
                plot(dataX1, dataY1, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 1, 'DisplayName', 'DataY1');
            end
            if ~isempty(dataY2)
                plot(dataX1, dataY2, 'r--s', 'LineWidth', 1.5, 'MarkerSize',1, 'DisplayName', 'DataY2');
            end
            xlabel('DataX1（X轴）', 'FontSize', 12);
            ylabel('数据值（Y轴）', 'FontSize', 12);
            %title('CHX=1 对应 DataX1 与 DataY1、DataY2 关系图', 'FontSize', 14, 'FontWeight', 'bold');
            legend('Location', 'best', 'FontSize', 10);
            hold off;
            
            % 9. 打印完整字段信息（含NumChannels）
            disp('===========================================');
            disp('完整字段信息（CHX=1）：');
            if isfield(resultStruct, 'Unixtime1')
                disp(['Unixtime1：', num2str(resultStruct.Unixtime1)]);
            end
            if isfield(resultStruct, 'CHX')
                disp(['CHX：', resultStruct.CHX]);
            end
            if isfield(resultStruct, 'NumChannels')
                disp(['NumChannels：', resultStruct.NumChannels]);
            end
            
            % 标记找到符合条件数据，退出循环
            isFound = true;
            break;
            
        else
            % CHX≠"1"，等待指定间隔（1秒）后继续下一次循环
            pause(loopInterval);
        end
        
    catch ME
        % 异常处理：请求失败时，打印错误信息，等待1秒后继续循环
        disp(['第', num2str(currentLoop), '次轮询出现错误：', ME.message]);
        disp('等待1秒后继续下一次轮询...');
        disp('-------------------------------------------');
        pause(loopInterval);
        continue;
    end
end

% 循环结束后，打印结果提示
if isFound
    disp('===========================================');
    disp('任务完成：已找到CHX=1的数据并完成绘图！');
else
    disp('===========================================');
    disp('任务终止：未找到符合条件的CHX=1数据！');
end

% ------------------------------
% 子函数：查找连续指定数量以上0的索引
% ------------------------------
function zeroIndices = findContinuousZeroIndices(dataArr, threshold)
    zeroIndices = [];
    dataArr = dataArr(:)';
    dataLen = length(dataArr);
    if dataLen < threshold
        return;
    end
    
    zeroMask = (dataArr == 0);
    diffMask = diff([0, zeroMask, 0]);
    startIndices = find(diffMask == 1);
    endIndices = find(diffMask == -1) - 1;
    
    for i = 1:length(startIndices)
        seqLength = endIndices(i) - startIndices(i) + 1;
        if seqLength >= threshold
            zeroIndices = [zeroIndices, (startIndices(i):endIndices(i))'];
        end
    end
end
